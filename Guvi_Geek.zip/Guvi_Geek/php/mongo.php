<?php
// connect to mongodb
//require_once '../vendor/autoload.php';
//echo extension_loaded("mongodb") ? "loaded\n" : "not loaded\n";
$m = new MongoDB\Driver\Manager('mongodb+srv://MadhavanR7:Maddy12345@cluster0.3k08mks.mongodb.net/db');
//echo "Connection to database successfully";
?>
